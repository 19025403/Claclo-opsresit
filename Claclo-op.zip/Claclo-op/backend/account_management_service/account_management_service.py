from flask import Flask, request, jsonify
from pymongo import MongoClient

app = Flask(__name__)
client = MongoClient('mongodb://mongodb-service:27017/')
db = client.claclo_ops
accounts = db.accounts

@app.route('/accounts/activate', methods=['POST'])
def activate_account():
    data = request.get_json()
    university_id = data.get('university_id')
    accounts.update_one({'university_id': university_id}, {'$set': {'status': 'active'}}, upsert=True)
    return jsonify({"message": f"University {university_id} activated."}), 200

@app.route('/accounts/deactivate', methods=['POST'])
def deactivate_account():
    data = request.get_json()
    university_id = data.get('university_id')
    accounts.update_one({'university_id': university_id}, {'$set': {'status': 'inactive'}})
    return jsonify({"message": f"University {university_id} deactivated."}), 200

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5001)
