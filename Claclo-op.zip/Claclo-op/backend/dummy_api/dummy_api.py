from flask import Flask, jsonify

app = Flask(__name__)

@app.route('/dummy/student', methods=['GET'])
def get_dummy_student_data():
    return jsonify({"student_id": "s123", "name": "John Doe", "course": "Computer Science"}), 200

@app.route('/dummy/teacher', methods=['GET'])
def get_dummy_teacher_data():
    return jsonify({"teacher_id": "t456", "name": "Jane Smith", "department": "Mathematics"}), 200

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5003)
