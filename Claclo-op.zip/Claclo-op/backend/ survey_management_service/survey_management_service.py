from flask import Flask, request, jsonify
from pymongo import MongoClient

app = Flask(__name__)
client = MongoClient('mongodb://mongodb-service:27017/')
db = client.claclo_ops
surveys = db.surveys

@app.route('/surveys/student', methods=['POST'])
def create_student_survey():
    data = request.get_json()
    survey_id = data.get('survey_id')
    surveys.insert_one(data)
    return jsonify({"message": "Survey created successfully", "survey_id": survey_id}), 200

@app.route('/surveys/student/results/<survey_id>', methods=['GET'])
def get_student_survey_results(survey_id):
    survey = surveys.find_one({"survey_id": survey_id})
    if survey:
        return jsonify({"survey_id": survey_id, "results": survey}), 200
    else:
        return jsonify({"error": "Survey not found"}), 404

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5002)
